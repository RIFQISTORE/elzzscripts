const axios = require('axios')

module.exports = async ({ q, lunatix, msg, sender, lunaticreply }) => {
    if (!q) return lunaticreply("⚠️ Kirim link TikTok-nya!\n\nContoh: *!ttdl https://vm.tiktok.com/xxx*")

    lunaticreply(mess.wait)

    try {
        const encodedParams = new URLSearchParams()
        encodedParams.set('url', q)
        encodedParams.set('hd', '1')

        const response = await axios({
            method: 'POST',
            url: 'https://tikwm.com/api/',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'Cookie': 'current_language=en',
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
            },
            data: encodedParams
        })

        const video = response.data?.data
        if (!video?.play) return lunaticreply("❌ Gagal ambil video TikTok")

        await lunatix.sendMessage(sender, {
            video: { url: video.play },
            caption: `🎬 *TikTok Downloader*\n\n📄 *Judul:* ${video.title || '-'}`
        }, { quoted: msg })

    } catch (err) {
        console.error("❌ TikTok DL Error:", err)
        lunaticreply(mess.error)
    }
}
