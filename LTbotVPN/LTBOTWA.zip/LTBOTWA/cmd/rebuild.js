const fs = require('fs');
const axios = require('axios');

const IMAGE_MAP = {
  'ubu22.04': 'ubuntu-22-04-x64',
  'ubu24.04': 'ubuntu-24-04-x64',
  'ubu24.10': 'ubuntu-24-10-x64',
  'deb11':    'debian-11-x64',
  'deb12':    'debian-12-x64',
};

module.exports = async (ctx) => {
  const { isAdmin, lunaticreply, args } = ctx;
  if (!isAdmin) return lunaticreply('❌ Khusus admin!');

  const [ipTarget, osAlias] = args;
  if (!ipTarget || !osAlias)
    return lunaticreply('❗ Format: !rebuild <ip> <os>\nContoh: !rebuild 157.245.1.1 ubu24.04');

  const imageSlug = IMAGE_MAP[osAlias.toLowerCase()];
  if (!imageSlug) return lunaticreply('❌ OS tidak dikenal!');

  const tokenPath = './avars/token.json';
  if (!fs.existsSync(tokenPath)) return lunaticreply('❌ Token tidak ditemukan!');
  
  const { digitalocean } = JSON.parse(fs.readFileSync(tokenPath));
  if (!digitalocean) return lunaticreply('❌ Token DigitalOcean kosong!');

  try {
    // 🔍 Cari droplet ID berdasarkan IP
    const res = await axios.get('https://api.digitalocean.com/v2/droplets', {
      headers: { Authorization: `Bearer ${digitalocean}` },
    });

    const droplets = res.data.droplets;
    const target = droplets.find(d =>
      d.networks.v4.find(net => net.type === 'public' && net.ip_address === ipTarget)
    );

    if (!target) return lunaticreply('❌ VPS dengan IP tersebut tidak ditemukan!');

    // 🔁 Kirim perintah rebuild
    await axios.post(
      `https://api.digitalocean.com/v2/droplets/${target.id}/actions`,
      { type: 'rebuild', image: imageSlug },
      { headers: { Authorization: `Bearer ${digitalocean}` } }
    );

    lunaticreply(`🔄 Sedang melakukan *rebuild* VPS ${ipTarget} ke *${osAlias}*...\n📬 Password baru akan dikirim via email DO.`);
  } catch (e) {
    console.error('Rebuild error:', e.response?.data || e.message);
    lunaticreply('❌ Gagal melakukan rebuild VPS. Cek IP & OS.');
  }
};
