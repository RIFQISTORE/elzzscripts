const fs = require('fs');
const image = './image/luna.png'; // pastikan path ini benar

  // Ambil prefix dari prefix.json
  let prefix = '!';
  try {
    const pf = JSON.parse(fs.readFileSync('./avars/prefix.json'));
    prefix = pf.prefix || '!';
  } catch {}
  // BATAS AMBIL GLOBAL PREFIX 
  
const menuText = `
*=======================*
     ☠️ MIZARBOTX ☠️
*=======================*
> ${prefix}ai 
> ${prefix}system
> ${prefix}gh   <link>
> ${prefix}halo <text>
> ${prefix}ftdl <text>
> ${prefix}view <link>
> ${prefix}ttdl <link>
> ${prefix}igdl <link>
> ${prefix}ytdl <link>
> ${prefix}crackmail <mail>
> ${prefix}gclink
> ${prefix}view <linkweb>
*=======================*
     GROUP FEATURE
*=======================*     
> ${prefix}promote
> ${prefix}demote
> ${prefix}tambahkan
*=======================*
      QR AND PAYMENT
*=======================*     
> ${prefix}qr
> ${prefix}pay     
*=======================*
    ME LUNA IS ADMINS
*=======================*
> ${prefix}jualan
> ${prefix}addowner
> ${prefix}dellowner
> ${prefix}listowner
> ${prefix}ban
> ${prefix}unban 
> ${prefix}installsc
> ${prefix}del
> ${prefix}adcmd
> ${prefix}editcmd
> ${prefix}resbot namabot
> ${prefix}delbot namabot
> ${prefix}startup namabot 
*=======================*
      VPS MANAGERS
*=======================*      
> ${prefix}buatVps
> ${prefix}rebuild
> ${prefix}listimages
> ${prefix}dataVps
> ${prefix}delvps
*=======================*
CREATE ACCOUNT PREMIUM
*=======================*
> ${prefix}advme
> ${prefix}advle
> ${prefix}adssh
> ${prefix}adtro
*=======================*
 CREATE ACCOUNT TRIALL
*=======================*
> ${prefix}trivme
> ${prefix}trivle
> ${prefix}trissh
> ${prefix}tritro
*=======================*
`;

module.exports = async ({ lunatix, msg, sender, lunaticreply }) => {
    try {
        const menuImage = fs.readFileSync(image);
        await lunatix.sendMessage(msg.key.remoteJid, {
            image: menuImage,
            caption: menuText,
            mentions: [sender]
        }, { quoted: msg });
    } catch (err) {
        console.error('❌ Error kirim menu:', err);
        lunaticreply('❌ Gagal mengirim menu.');
    }
};
