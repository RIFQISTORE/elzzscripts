const os = require('os')
const { performance } = require('perf_hooks')

module.exports = async ({ lunatix, msg, sender, lunaticreply, isAdmin }) => {
    if (!isAdmin) return lunaticreply("❌ Khusus owner bot!");

    try {
        // RAM
        const totalRAM = os.totalmem() / 1024 / 1024 // Dalam MB
        const freeRAM = os.freemem() / 1024 / 1024
        const usedRAM = totalRAM - freeRAM
        const ramUsage = ((usedRAM / totalRAM) * 100).toFixed(2)

        // CPU
        const cpus = os.cpus()
        const cpuModel = cpus[0].model
        const cpuCores = cpus.length
        const cpuSpeed = cpus[0].speed // MHz
        const loadAvg = os.loadavg()[0].toFixed(2) // 1 menit

        // Uptime
        const uptimeSec = os.uptime()
        const uptimeH = Math.floor(uptimeSec / 3600)
        const uptimeM = Math.floor((uptimeSec % 3600) / 60)
        const uptimeS = Math.floor(uptimeSec % 60)

        // Ping
        const start = performance.now()
        await lunatix.sendPresenceUpdate('composing', sender)
        const ping = (performance.now() - start).toFixed(2)

        // Format Pesan
        const info = `🖥️ *System Status*\n\n` +
            `🔋 *RAM*\n` +
            `• Total  : ${totalRAM.toFixed(2)} MB\n` +
            `• Used   : ${usedRAM.toFixed(2)} MB\n` +
            `• Free   : ${freeRAM.toFixed(2)} MB\n` +
            `• Usage  : ${ramUsage}%\n\n` +

            `🧠 *CPU*\n` +
            `• Model  : ${cpuModel}\n` +
            `• Cores  : ${cpuCores} Core(s)\n` +
            `• Speed  : ${cpuSpeed} MHz\n` +
            `• Load   : ${loadAvg}\n\n` +

            `⏱️ *Uptime*\n` +
            `• ${uptimeH}h ${uptimeM}m ${uptimeS}s\n\n` +

            `📶 *Ping*\n` +
            `• ${ping} ms`

        await lunaticreply(info)
    } catch (err) {
        console.error("❌ Error system status:", err)
        lunaticreply("⚠ Gagal mendapatkan informasi sistem.")
    }
}
