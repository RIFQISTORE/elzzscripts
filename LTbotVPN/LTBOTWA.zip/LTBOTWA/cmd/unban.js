const fs = require('fs');
const path = './avars/banned.json';

module.exports = async ({ lunaticreply, q, isAdmin }) => {
    if (!isAdmin) return lunaticreply("❌ Perintah ini hanya untuk admin!");

    if (!q) return lunaticreply("⚠️ Masukkan nomor yang ingin di-unban!\nContoh:\n!unban 6281234567890");

    const banned = JSON.parse(fs.readFileSync(path));
    const nomor = q.replace(/[^0-9]/g, '') + '@s.whatsapp.net';

    if (!banned.includes(nomor)) {
        return lunaticreply("❌ Nomor ini belum diblokir.");
    }

    const index = banned.indexOf(nomor);
    banned.splice(index, 1);
    fs.writeFileSync(path, JSON.stringify(banned, null, 2));

    lunaticreply(`✅ Nomor *${nomor}* berhasil di-*unban*.`);
};
