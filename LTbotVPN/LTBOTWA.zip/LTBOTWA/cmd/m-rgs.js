const { sendMenu, userMenus } = require('../handler');

module.exports = (bot, chatId, _query, _pendingInputs) => {
  const inline_keyboard = [
    [
      { text: 'VPS MONITOR', callback_data: 'vpsinfo' },
      { text: 'VPS SERVICE', callback_data: 'vpsserv' },
      { text: 'VPS RESTART', callback_data: 'vpsrest' }      
    ],
    [
      { text: 'SET BOTNOTIF', callback_data: 'botnotif' },
      { text: 'DEL BOTNOTIF', callback_data: 'delbotnotif'},
      { text: 'QUIT TO MENU', callback_data: 'menu_back'}      
    ]    
  ];

  const opts = {
    parse_mode: 'Markdown',
    reply_markup: { inline_keyboard }
  };

  sendMenu(bot, chatId, userMenus, '*SELECT CHOICE:*', opts);
};
